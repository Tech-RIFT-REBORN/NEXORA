-- NEXORA Supabase setup: public accounts + admin dashboard
-- Run this in Supabase SQL Editor.

create table if not exists public.requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  client_name text not null check (char_length(client_name) between 1 and 80),
  discord_username text not null check (char_length(discord_username) between 1 and 80),
  server_type text not null,
  service_needed text not null,
  budget text not null,
  details text not null check (char_length(details) between 1 and 2000),
  status text not null default 'Pending'
    check (status in ('Pending','In Progress','Completed','Cancelled')),
  created_at timestamptz not null default now()
);

alter table public.requests enable row level security;

-- If upgrading an existing NEXORA database, add user_id first.
alter table public.requests
  add column if not exists user_id uuid references auth.users(id) on delete cascade;

-- Public users must be signed in to submit.
drop policy if exists "Public can submit requests" on public.requests;
drop policy if exists "Signed in users can submit requests" on public.requests;
create policy "Signed in users can submit requests"
on public.requests
for insert
to authenticated
with check (auth.uid() = user_id);

-- Admin access: replace YOUR_ADMIN_USER_ID with your Supabase Auth user UUID.
-- This keeps public accounts from seeing the admin request data.
drop policy if exists "Admin can read requests" on public.requests;
create policy "Admin can read requests"
on public.requests
for select
to authenticated
using (auth.uid() = 'YOUR_ADMIN_USER_ID'::uuid);

drop policy if exists "Admin can update requests" on public.requests;
create policy "Admin can update requests"
on public.requests
for update
to authenticated
using (auth.uid() = 'YOUR_ADMIN_USER_ID'::uuid)
with check (auth.uid() = 'YOUR_ADMIN_USER_ID'::uuid);

drop policy if exists "Admin can delete requests" on public.requests;
create policy "Admin can delete requests"
on public.requests
for delete
to authenticated
using (auth.uid() = 'YOUR_ADMIN_USER_ID'::uuid);

grant insert on public.requests to authenticated;
grant select, update, delete on public.requests to authenticated;
